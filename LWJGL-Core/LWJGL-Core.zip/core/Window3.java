package core;

public class Window3 {

	long window;

	public Window3(String title){
		
	}
	
}
