package util;

public class IndexVec {

	public int x, y;
	
	public IndexVec(int x, int y){
		this.x = x;
		this.y = y;
	}
	
}
